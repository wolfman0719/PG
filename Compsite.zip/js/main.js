'use strict';

angular.module('myApp', ['quramy-recursive']).controller('Ctrl', ['$scope', '$http', function($scope,$http){
	
	var treeData = {};
	
		$http.get('/rest/company/18').then(
		function(response) {
			$scope.treeData = response.data;
		}
		, function(response) {
			$scope.message = "http request error";
		});
    
	
	$scope.addChild = function(data){
		if(!data.orgs){
			data.orgs = [];
		}
		data.orgs.push({
			name: data.newName
		});
		data.newName = '';
	};

	$scope.removeChild = function(data, i){
		data.orgs.splice(i, 1);
	};

	$scope.title = 'my tree data';

	
}]);
