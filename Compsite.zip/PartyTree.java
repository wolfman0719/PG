import java.awt.*;
import java.awt.event.*;
import java.util.*;
import com.intersys.objects.*;

//swing classes
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.tree.*;


public class PartyTree extends JxFrame
   implements TreeSelectionListener
{
   static final long serialVersionUID = 0;
   JScrollPane sp;
   JPanel treePanel;
   JTree tree;
   DefaultMutableTreeNode troot;
   JLabel cost;
   Sample.Party party;
   Database         dbconnection = null;

   public PartyTree()
      {
         super("組織図");
         setCloseClick();
         party = loadParties();
         setGUI(party);
      }
   //--------------------------------------
      public void setGUI(Sample.Party party)
      {
         treePanel = new JPanel();
         getContentPane().add(treePanel);
         treePanel.setLayout(new BorderLayout());

         sp = new JScrollPane();
         treePanel.add("Center", sp);
         treePanel.add("South", cost = new JLabel("          "));

         treePanel.setBorder(new BevelBorder(BevelBorder.RAISED));
         try {
           troot = new DefaultMutableTreeNode(party.getName());
         } catch (Exception ex) {
            System.out.println( "例外発生0: " + ex.getClass().getName() + ": " + ex.getMessage() );
            ex.printStackTrace();
         }
         tree= new JTree(troot);
         tree.setBackground(Color.lightGray);
         loadTree(party);
         /* スクローラーにツリーを置く */

         sp.getViewport().add(tree);
         setSize(new Dimension(200, 300));
         setVisible(true);

      }
      //------------------------------------
      public void loadTree(Sample.Party topDog)
       {
         DefaultMutableTreeNode troot = null;
         try {
           troot = new DefaultMutableTreeNode(topDog.getName());
         } catch (Exception ex) {
            System.out.println( "例外発生0: " + ex.getClass().getName() + ": " + ex.getMessage() );
            ex.printStackTrace();
         }
         treePanel.remove(tree);
         tree= new JTree(troot);
         tree.addTreeSelectionListener(this);
         sp.getViewport().add(tree);

         addNodes(troot, topDog);
         tree.expandRow(0);
         repaint();
      }

    //--------------------------------------
    private void addNodes(DefaultMutableTreeNode pnode, Sample.Party party) {
        DefaultMutableTreeNode node;

        try {
          Iterator e = party.SubNodes().iterator();
          if (e != null) {
              while (e.hasNext()) {
                  Sample.Party newParty = (Sample.Party)e.next();
                  node = new DefaultMutableTreeNode(newParty.getName());
                  pnode.add(node);
                  addNodes(node, newParty);
                }
            }
        } catch (Exception ex) {
          System.out.println( "例外発生0: " + ex.getClass().getName() + ": " + ex.getMessage() );
          ex.printStackTrace();
        }
    }

      //--------------------------------------
      public Sample.Party loadParties()
      {
        String           url="jdbc:Cache://localhost:1972/USER";
        String           username="_SYSTEM";  // 既定値は、null
        String           password="SYS";  // 既定値は、null
        Sample.Party          party = null;
        Sample.Employee       emp = null;
        Sample.Department     dept = null;
        Id              oid = null;

        boolean isQuick = false;

        try {
            /* ローカルのテスト用ネームスペースに接続 */
            if (isQuick)
                dbconnection = CacheDatabase.getLightDatabase (url, username, password);
            else
                dbconnection = CacheDatabase.getDatabase (url, username, password);

            System.out.println( "接続完了" );

            /* Sample.Partyオブジェクトのインスタンスをオープン */
            if (oid == null)
                oid = new Id( 18 );

            if (!(Sample.Party.exists (dbconnection, oid)))
                {
                    System.out.println ("該当idを持つPartyはこのデータベース内にありません " +
                                        oid.toString());
                    dbconnection.close();
                    return null;
                }

            party = (Sample.Party) Sample.Party._open( dbconnection, oid );
            System.out.println("クラス名 = " + party._className());

            return party;

        } catch (CacheException ex) {
            System.out.println( "例外発生0: " + ex.getClass().getName() + ": " + ex.getMessage() );
            ex.printFullTrace(System.out);
            return null;
        } catch (Exception ex) {
            System.out.println( "例外発生0: " + ex.getClass().getName() + ": " + ex.getMessage() );
            ex.printStackTrace();
            return null;
        }
    }

      //--------------------------------------
      public void valueChanged(TreeSelectionEvent evt)
      {
       TreePath path = evt.getPath();
       //String selectedTerm = path.getLastPathComponent().toString();

       //Employee emp = boss.getChild(selectedTerm);
       //if(emp != null)
          //cost.setText(new Float(emp.getSalaries()).toString());
      }

      private void setCloseClick()
      {
         //create window listener to respond to window close click
         addWindowListener(new WindowAdapter()
          {

            public void windowClosing(WindowEvent e) {
            /* un-assign the objects */
            try {
            dbconnection.closeObject(party.getOref());
            party = null;
            /* Close the connection */
            dbconnection.close();
            } catch (CacheException ex) {
                System.out.println( "例外発生0: " + ex.getClass().getName() + ": " + ex.getMessage() );
                ex.printFullTrace(System.out);
            } catch (Exception ex) {
                System.out.println( "例外発生0: " + ex.getClass().getName() + ": " + ex.getMessage() );
                ex.printStackTrace();
            }
            System.out.println( "接続切断" );
            System.exit(0);}
            });
        }

      //--------------------------------------
      static public void main(String argv[])
      {
         new PartyTree();
      }
}
