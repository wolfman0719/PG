﻿
Caché Objectサンプル


1.　はじめに

このサンプルは、Cachéオブジェクトサンプルです。

オブジェクトパターンとして有名なコンポジットパターンをCachéで実装して
います。

2.　サンプルキットの構成

このキットには以下のファイルが含まれます。

2.1 parties.gif

サンプルに含まれるクラスのクラス図

2.2 party.xml

サンプルに含まれるクラスのCachéクラス定義、ルーチン、グローバルデータ


2.5 PartyTree.java

Tree Viewに組織階層を表示するサンプル

2.6 Sample\*.java

CachéクラスのプロキシJavaクラス

3.　インストレーション方法

3.0. 動作可能Cachéバージョン

V2010以降

3.1. Composite.zipをWinZip等のツールで適当なディレクトリに解凍して下さい。

3.2  Party.xmlをUSERネームスペースにインポート


4.　実行方法

4.1　PrintParties

>Do ^PrintParties()

4.2  PartyTree.java


CLASSPATH にc:\InterSystems\Cache\dev\java\lib\JDK18\cache-db-n.n.n.jarを追加
CLASSPATH にc:\InterSystems\Ensemble\dev\java\lib\JDK18\cache-db-n.n.n.jarを追加

n.n.nはバージョン番号　例　2.0.0

5. 追加サンプル

5.0　クラスのロード

　　PartyUtils.cls（UDL形式）

5.1  階層の異なるデータの追加(一度のみ実行)


>write w ##class(Sample.PartyUtils).Populate4tiers()
>write w ##class(Sample.PartyUtils).Populate2tiers()

5.2 Topからの5.1データ切り離し

>w ##class(Sample.PartyUtils).Detach2tiers()
>w ##class(Sample.PartyUtils).Detach4tiers()

5.3 Topに5.1データを再リンク

>write ##class(Sample.PartyUtils).Attach2tiers()
>write ##class(Sample.PartyUtils).Attach4tiers()

6. REST/JSONのサンプル

Angularを使用したREST/JSONサンプル
 
 tree.html
 lib\angular.min.js
 lib\angular-recursive.js
 lib\main.js
 
 Dispatch.cls(UDL形式）)		REST用ディスパッチクラス
 
 /restというREST用のwebアプリケーションを設定
 
 参考　rest-setup.jpg
 
 
 