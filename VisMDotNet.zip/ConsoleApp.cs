using System;

// Add the following using statement
using InterSystems.Data.CacheClient;
using InterSystems.Data.CacheTypes;

namespace cdapp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class ConsoleApp
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{

			//
			// TODO: Add code to start application here
			//
            try
            {
                // Create a cacheDirectWapper instance
                cacheDirectWapper cdw = new cacheDirectWapper("Server = localhost; Log File=cprovider.log;Port=1972; Namespace=USER; Password = SYS; User ID = _system;");

                cdw.cd.P0 = "ABC;DEF;GHI";
                cdw.cd.P1 = ";";
                cdw.cd.PDELIM = ";";

                cdw.cd.Execute("=$PIECE(P0,P1,2)");

                Console.Write("P1 = " + cdw.cd.P1);
                Console.Write("\n");
                Console.Write("Value = " + cdw.cd.Value);
                Console.Write("\n");
                Console.Write("ErrorName = " + cdw.cd.ErrorName);
                Console.Write("\n");

                cdw.cd.Execute("set PLIST(1)= 123,PLIST(2)=456,PLIST(3)=7890");

                Console.Write("PLIST(1) = " + cdw.getPLIST(1));
                Console.Write("\n");
                Console.Write("PLIST(2) = " + cdw.getPLIST(2));
                Console.Write("\n");
                Console.Write("PLIST(3) = " + cdw.getPLIST(3));
                Console.Write("\n");
                Console.Write("ErrorName = " + cdw.cd.ErrorName);
                Console.Write("\n");

                // Cleanup CachedirectWapper

                cdw.end();
            }
            finally
            {
            }
		}
	}
}
