using System;

// Add the following using statement
using InterSystems.Data.CacheClient;
using InterSystems.Data.CacheTypes;

namespace C_SharpConsoleExample
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class ConsoleApp
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{

			//
			// TODO: Add code to start application here
			//

			// Create a connection to Cache
			CacheConnection conn = new CacheConnection();

			// Cache server Connection Information
			// Set Server to your IP address and port to Cache SuperServer port, Log File is optional
            conn.ConnectionString = "Server = localhost; Log File=c:\\temp\\cprovider.log;Port=1972; Namespace=USER; Password = SYS; User ID = _SYSTEM;";
			
			//Open a Connection to Cache

			conn.Open();

            User.CacheDirect cd = new User.CacheDirect(conn);

            cd.P0 = "ABC;DEF;GHI";
            cd.P1 = ";";


            cd.Execute("=$PIECE(P0,P1,2)");
      
			Console.Write("P1 = " + cd.P1);
            Console.Write("\n");
            Console.Write("Value = " + cd.Value);
            Console.Write("\n");
            Console.Write("ErrorName = " + cd.ErrorName);

			// Cleanup Cachedirect
	
            cd.Dispose();
			conn.Close();
		}
	}
}
