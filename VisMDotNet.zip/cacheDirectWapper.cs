using System;
using InterSystems.Data.CacheClient;
using InterSystems.Data.CacheTypes;

namespace cdapp
{
    public class cacheDirectWapper
    {
        CacheConnection conn;
        public User.CacheDirect cd; 
        public cacheDirectWapper(string constr)
        {
            try
            {
                conn = new CacheConnection();
                conn.ConnectionString = constr;
                conn.Open();
                cd = new User.CacheDirect(conn);
            }
            finally
            {
            }
        }

        public Boolean end() {

            try
            {

                cd.Dispose();
                conn.Close();
            }
            finally
            {
            }
            return true;
        }

        public string getPLIST(int index) {

           string[] PLISTArray = cd.PLIST.Split(cd.PDELIM.ToCharArray());

           return PLISTArray[index -1];
        }

        public Boolean setPLIST(int index, string replace) {

           string[] PLISTArray = cd.PLIST.Split(cd.PDELIM.ToCharArray());

           PLISTArray[index - 1] = replace;
           cd.PLIST = string.Join(cd.PDELIM,PLISTArray);
           return true;
        }
   }
}
